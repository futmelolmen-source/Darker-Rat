import os
import sys
import subprocess
import pkgutil
import importlib.util
import re
from pathlib import Path

def get_standard_libs():
    """Возвращает множество встроенных модулей Python."""
    std_libs = set(sys.builtin_module_names)
    # Добавляем модули из стандартной библиотеки по пути
    try:
        import sysconfig
        stdlib_path = Path(sysconfig.get_path("stdlib"))
        if stdlib_path.exists():
            for item in stdlib_path.iterdir():
                if item.is_dir() or (item.suffix == ".py"):
                    std_libs.add(item.stem)
    except Exception:
        pass
    # Добавляем все доступные модули из pkgutil (часть stdlib + site-packages, но фильтрация ниже)
    for importer, modname, ispkg in pkgutil.iter_modules():
        # Мы не можем точно отделить stdlib от site-packages здесь,
        # но ниже будем проверять через find_spec + исключения
        pass
    return std_libs

def extract_imports_from_file(filepath):
    """Извлекает имена модулей из import-выражений в файле."""
    imports = set()
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
    except Exception:
        return imports

    # Ищем строки вида: import xxx или from xxx import ...
    import_lines = re.findall(r'^\s*(?:import|from)\s+([a-zA-Z_][a-zA-Z0-9_.]*)', content, re.MULTILINE)
    for line in import_lines:
        top_level = line.split('.')[0]
        if top_level and not top_level.startswith('_'):
            imports.add(top_level)
    return imports

def is_package_installed(package_name):
    """Проверяет, установлен ли пакет."""
    try:
        importlib.util.find_spec(package_name)
        return True
    except (ImportError, ValueError, AttributeError):
        return False

def install_package(package_name):
    """Устанавливает пакет через pip."""
    print(f"Устанавливаю {package_name}...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", package_name])
    except subprocess.CalledProcessError as e:
        print(f"Ошибка при установке {package_name}: {e}")

def main():
    script_dir = Path(__file__).parent.resolve()
    py_files = list(script_dir.glob("*.py"))

    if not py_files:
        print("Нет .py файлов в текущей папке.")
        wait_for_click()
        return

    print(f"Найдено {len(py_files)} .py файлов. Анализирую зависимости...")

    all_imports = set()
    for py_file in py_files:
        imports = extract_imports_from_file(py_file)
        all_imports.update(imports)

    # Получаем список встроенных модулей
    std_libs = get_standard_libs()

    # Фильтруем: только сторонние пакеты (не встроенные)
    third_party = [imp for imp in all_imports if imp not in std_libs]

    # Убираем дубликаты и пустые строки
    third_party = sorted(set(filter(None, third_party)))

    if not third_party:
        print("Сторонние зависимости не обнаружены.")
        wait_for_click()
        return

    print(f"Обнаружены возможные сторонние зависимости: {third_party}")

    missing = []
    for pkg in third_party:
        if not is_package_installed(pkg):
            missing.append(pkg)

    if not missing:
        print("Все зависимости уже установлены.")
    else:
        print(f"Отсутствуют пакеты: {missing}")
        for pkg in missing:
            install_package(pkg)

    wait_for_click()

def wait_for_click():
    """Ждёт нажатия Enter перед закрытием."""
    try:
        input("\nНажмите Enter, чтобы выйти...")
    except KeyboardInterrupt:
        print("\nВыход по запросу пользователя.")

if __name__ == "__main__":
    main()